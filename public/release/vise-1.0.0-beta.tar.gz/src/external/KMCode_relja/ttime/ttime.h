#ifndef _ttime_h_
#define _ttime_h_

extern double tell_time (long count_time);
extern void init_time (long *count_time);


#endif
