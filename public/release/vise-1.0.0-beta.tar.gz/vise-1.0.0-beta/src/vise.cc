/** @file   vise.cc
 *  @brief  main entry point for the VGG Image Search Enginer (VISE)
 *
 *  @author Abhishek Dutta (adutta@robots.ox.ac.uk)
 *  @date   31 March 2017
 */

#include <iostream>
#include <string>

#include <boost/filesystem.hpp>

#include <Magick++.h>            // to transform images

#include "ViseServer.h"

int main(int argc, char** argv) {
  std::cout << "\nVGG Image Search Engine (VISE)";
  std::cout << "\n";
  //unsigned int port = 9973;
  unsigned int port = 8080;

  Magick::InitializeMagick(*argv);

  std::string user_home = getenv("HOME");
  boost::filesystem::path home(user_home);
  boost::filesystem::path vgg = home / "vgg";
  boost::filesystem::path vise = vgg / "vise";
  boost::filesystem::path vise_src = vise / "vise_src";
  boost::filesystem::path vise_data = vise / "vise_data";
  boost::filesystem::path vise_template = vise_src / "vise/src/server/html_templates/";

  ViseServer vise_server( vise_data, vise_template );
  //vise_server.InitResources( visedata_dir, template_dir );

  vise_server.Start(port);

  // server is stopped by sending the following HTTP POST request
  // POST /
  // shutdown_vise now (the POST data)
  return 0;
}
