# Meta data for pypar
__version__ = '2.1.4'
__date__ = '22 December 2010'
__author__ = 'Ole M. Nielsen'


