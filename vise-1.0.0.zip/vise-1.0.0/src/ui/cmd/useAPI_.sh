#!/bin/bash
while nc $@; do echo ""; done
