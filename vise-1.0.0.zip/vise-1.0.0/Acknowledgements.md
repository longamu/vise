# Acknowledgement

 * [Relja Arandjelovic]
   * for sharing his original codebase `relja_retrival`
   * for answering many questions during the code upgrade and debugging sessions


Abhishek Dutta  
27 March 2017
