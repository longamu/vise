sudo apt-get install \
    python \
    python-numpy \
    python-cherrypy3 \
    libcairo2 libjpeg62

echo "Now install jp_draw if you want the details page"
