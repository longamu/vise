sudo apt-get install \
    build-essential \
    cython

./online_frontend.sh

echo "Now build jp_draw if you want the details page"
