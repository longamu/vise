mkdir ../build
cmake ../src
make -j8
