sudo apt-get install \
    build-essential \
    cmake \
    imagemagick \
    protobuf-compiler

./online_backend.sh

echo "Now build FASTANN"
