# Contributing to VISE
The version 1.0.0 release of VISE is intended to serve user's image search needs.
In the future versions, we will update the source code documentation and 
architectural design of VISE so that it is easier to understand the VISE C++ codebase.


